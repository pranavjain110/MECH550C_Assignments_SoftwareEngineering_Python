# Assignment 2- MECH550C

---
Title: Comparing areas of two rectangles

Author: Pranav Jain


---

## Description
This program compares areas of two rectangles and returns True if the areas are equal and False if the areas are unequal.

**main.exe** file is compiled for a case when the areas are equal and it prints True


## Execution
Run **main.exe** to see the output of the the program

## Dependencies
- Python 3.8.1

## IDE
- Visual Studio Code
