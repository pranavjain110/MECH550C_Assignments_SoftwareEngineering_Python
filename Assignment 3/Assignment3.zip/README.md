# Assignment 3- MECH550C

---
Title: Multiply two matrices containing complex numbers

Author: Pranav Jain


---

## Description
The program inputs list containg elements of a matrix and stores each element of the list as an object of class Complex numbers. The matrices are stored as private variables and can be only acccesed through the public functions of the same class. 
The program also has a class called ComplexMultiplication which contains methods required to multiply the matrices 

**main.exe** file is compiled for the following cases:
- Multiplication of a 2x2 matrix with a 2x2 matrix
- Multiplication of a 2x3 matrix with a 3x2 matrix

However we could multiply any two matrices as long as they follow the rule of matrix multiplication.

## Execution
Run **main.exe** to see the output of the the program

## Dependencies
- Python 3.8.1
- pyInstaller is used to convert the following code into .exe file
## IDE
- Visual Studio Code
