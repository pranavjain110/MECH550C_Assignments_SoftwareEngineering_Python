# File Header
# Name: Pranav Jain
# Student Number = 14213029
# Source File: main.py
# Course: MECH 550C - Software Design
# Description: Program to print a string
# Usage: Run Lab1.exe

print ("Using python I aim to make small apps that \
supports any automation I carry out in the industry.")

input("\nPress Enter to Exit ")