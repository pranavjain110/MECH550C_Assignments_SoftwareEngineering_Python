# File Header
# Name: Pranav Jain
# Student Number = 14213029
# Source File: main.py
# Course: MECH 550C - Software Design
# Description: Program to print a string
# Usage: Run Lab1.exe

#print() command prints a sequence of characters
print ("Using python I aim to make small apps that \
support any automation I carry out in the industry.")

#input() command is used to exit the program when the users presses enter
input("\nPress Enter to Exit ")