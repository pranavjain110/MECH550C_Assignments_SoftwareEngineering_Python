# Hello World Application

This code is written to get familiar with python and the Visual Studio Code IDE.

The program uses the following commands:
1. print() - to display a sequence of characters
2. input() - to get an input from the user

input() command has been used in order to prevent the application window from getting closed untill the user presses the Enter key.
